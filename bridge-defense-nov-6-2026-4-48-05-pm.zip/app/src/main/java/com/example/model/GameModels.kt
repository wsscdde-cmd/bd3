package com.example.model

enum class AppScreen {
  MAIN_MENU,
  GAMEPLAY
}

enum class GameMode(val titleRu: String, val subtitleRu: String) {
  ENDLESS(
    titleRu = "Бесконечный Режим",
    subtitleRu = "Враги усиливаются до бесконечности, появляются новые мутанты и боссы. Добывайте Кристаллы 💎 в каждом забеге!"
  ),
  CAMPAIGN(
    titleRu = "Кампания (Волны)",
    subtitleRu = "Последовательная оборона моста от волны к волне с финальным Боссом на каждом этапе."
  )
}

enum class Lane {
  LEFT,
  CENTER,
  RIGHT
}

enum class PlantType(
  val titleRu: String,
  val descriptionRu: String,
  val baseHitsRequired: Int,
  val fireIntervalSec: Float,
  val baseDamage: Int,
  val splashRadius: Float
) {
  SPIDER_SHOOTER(
    titleRu = "Паучок-Стрелок",
    descriptionRu = "Скорострельный куст в горшке. Пускает острые семена по ближайшим зомби.",
    baseHitsRequired = 55,
    fireIntervalSec = 0.32f,
    baseDamage = 45,
    splashRadius = 0f
  ),
  EGGPLANT_MORTAR(
    titleRu = "Баклажан-Мортира",
    descriptionRu = "Фиолетовая мортира с зелёным чубом. Стреляет разрывными снарядами по толпе.",
    baseHitsRequired = 140,
    fireIntervalSec = 0.90f,
    baseDamage = 145,
    splashRadius = 0.105f
  ),
  ANGRY_FLOWER(
    titleRu = "Гневный Ромашек",
    descriptionRu = "Суровый цветок, поражающий плотные ряды зомби солнечным импульсом.",
    baseHitsRequired = 260,
    fireIntervalSec = 0.65f,
    baseDamage = 220,
    splashRadius = 0.085f
  ),
  FROST_CACTUS(
    titleRu = "Ледяной Бутон",
    descriptionRu = "Замораживает ряды зомби на мосту, замедляя их натиск.",
    baseHitsRequired = 400,
    fireIntervalSec = 0.80f,
    baseDamage = 165,
    splashRadius = 0.115f
  )
}

enum class UpgradeType(
  val labelRu: String,
  val baseHitsRequired: Int
) {
  FIRE_RATE_BOOST("Темп +18%", 45),
  ATTACK_BOOST("Урон +24%", 75),
  BULLETS_PLUS_1("Снаряды +1", 130),
  HERO_PLUS_1("Герой +1", 180)
}

enum class ZombieType(
  val nameRu: String,
  val descriptionRu: String,
  val minThreatLevel: Int,
  val hpMultiplier: Float,
  val speedMultiplier: Float,
  val armorReduction: Float,
  val scale: Float,
  val goldReward: Int,
  val crystalChance: Float
) {
  NORMAL(
    nameRu = "Рядовой Зомби",
    descriptionRu = "Обычный пехотинец орды в оранжевом свитере.",
    minThreatLevel = 1,
    hpMultiplier = 1.0f,
    speedMultiplier = 1.0f,
    armorReduction = 0f,
    scale = 1.0f,
    goldReward = 5,
    crystalChance = 0.025f
  ),
  SPRINTER(
    nameRu = "Бешеный Бегун",
    descriptionRu = "Стремительно бежит к ленте опасности. Мало ХП, но высокая скорость.",
    minThreatLevel = 2,
    hpMultiplier = 0.75f,
    speedMultiplier = 1.40f,
    armorReduction = 0f,
    scale = 0.94f,
    goldReward = 7,
    crystalChance = 0.06f
  ),
  CONEHEAD(
    nameRu = "Штурмовик в Каске",
    descriptionRu = "Защищён дорожным конусом, выдерживает в 2 раза больше попаданий.",
    minThreatLevel = 2,
    hpMultiplier = 2.0f,
    speedMultiplier = 0.94f,
    armorReduction = 0.08f,
    scale = 1.06f,
    goldReward = 10,
    crystalChance = 0.08f
  ),
  SHIELD_BRUTE(
    nameRu = "Щитоносец",
    descriptionRu = "Несёт тяжёлый стальной щит, поглощающий 25% входящего урона.",
    minThreatLevel = 3,
    hpMultiplier = 3.2f,
    speedMultiplier = 0.82f,
    armorReduction = 0.25f,
    scale = 1.16f,
    goldReward = 16,
    crystalChance = 0.16f
  ),
  TOXIC_MUTANT(
    nameRu = "Кислотный Мутант",
    descriptionRu = "Радиоактивный зомби с огромным запасом здоровья и быстрой походкой.",
    minThreatLevel = 4,
    hpMultiplier = 2.8f,
    speedMultiplier = 1.18f,
    armorReduction = 0.12f,
    scale = 1.12f,
    goldReward = 20,
    crystalChance = 0.22f
  ),
  NECRO_SHAMAN(
    nameRu = "Зомби-Шаман",
    descriptionRu = "Тёмный колдун, периодически исцеляющий всех зомби вокруг себя!",
    minThreatLevel = 5,
    hpMultiplier = 3.5f,
    speedMultiplier = 0.86f,
    armorReduction = 0.15f,
    scale = 1.14f,
    goldReward = 26,
    crystalChance = 0.32f
  ),
  CYBER_JUGGERNAUT(
    nameRu = "Кибер-Джаггернаут",
    descriptionRu = "Тяжёлый бронированный киборг-мутант на высоких уровнях угрозы.",
    minThreatLevel = 7,
    hpMultiplier = 6.2f,
    speedMultiplier = 0.76f,
    armorReduction = 0.32f,
    scale = 1.30f,
    goldReward = 38,
    crystalChance = 0.48f
  ),
  BOSS(
    nameRu = "Титан-Гаргантюа (Босс)",
    descriptionRu = "Колоссальный предводитель орды. Сокрушает оборону при прорыве.",
    minThreatLevel = 1,
    hpMultiplier = 16.0f,
    speedMultiplier = 0.58f,
    armorReduction = 0.20f,
    scale = 1.85f,
    goldReward = 100,
    crystalChance = 1.0f
  )
}

data class LeftBarrel(
  val id: Long,
  val y: Float,
  val hp: Int,
  val maxHp: Int,
  val plantType: PlantType,
  val hitFlash: Float = 0f
)

data class ActiveTurret(
  val id: Long,
  val slotIndex: Int,
  val y: Float,
  val plantType: PlantType,
  val level: Int = 1,
  val cooldown: Float = 0f,
  val recoilAnim: Float = 0f
)

data class RightBarrel(
  val id: Long,
  val y: Float,
  val hp: Int,
  val maxHp: Int,
  val upgradeType: UpgradeType,
  val bonusAmount: Int,
  val hitFlash: Float = 0f
)

data class Zombie(
  val id: Long,
  val x: Float,
  val y: Float,
  val rowId: Int,
  val colIndex: Int,
  val hp: Int,
  val maxHp: Int,
  val type: ZombieType,
  val walkPhase: Float = 0f,
  val hitFlash: Float = 0f,
  val slowTimer: Float = 0f,
  val healPulseTimer: Float = 2.5f
)

enum class ProjectileStyle {
  STANDARD_BULLET,
  CRIT_BULLET,
  LEFT_GATE_BLUE,
  RIGHT_GATE_FIRE,
  PLANT_SEED,
  EGGPLANT_BOMB,
  SOLAR_FLARE,
  FROST_SHARD
}

data class Projectile(
  val id: Long,
  val x: Float,
  val y: Float,
  val vx: Float,
  val vy: Float,
  val damage: Int,
  val style: ProjectileStyle,
  val passedGate: Boolean = false,
  val splashRadius: Float = 0f,
  val appliesSlow: Boolean = false
)

data class FloatingText(
  val id: Long,
  val x: Float,
  val y: Float,
  val text: String,
  val colorHex: Long,
  val scale: Float = 1.0f,
  val alpha: Float = 1.0f,
  val life: Float = 0.9f
)

data class VisualParticle(
  val id: Long,
  val x: Float,
  val y: Float,
  val vx: Float,
  val vy: Float,
  val radius: Float,
  val colorHex: Long,
  val alpha: Float = 1.0f,
  val life: Float = 0.45f
)

data class PlayerStats(
  val totalRunsPlayed: Int = 0,
  val totalZombiesKilled: Long = 0L,
  val totalBossesKilled: Int = 0,
  val totalElitesKilled: Int = 0,
  val totalLeftBarrelsBroken: Int = 0,
  val totalRightBarrelsBroken: Int = 0,
  val bestEndlessThreatLevel: Int = 1,
  val bestEndlessTimeSec: Int = 0,
  val bestScore: Int = 0,
  val highestCampaignWave: Int = 1,
  val lifetimeGoldEarned: Long = 0L,
  val lifetimeCrystalsEarned: Long = 0L,
  val claimedAchievementIds: Set<String> = emptySet()
)

data class AchievementDef(
  val id: String,
  val titleRu: String,
  val descriptionRu: String,
  val rewardCrystals: Int,
  val currentProgress: Int,
  val targetProgress: Int,
  val isClaimed: Boolean
) {
  val isCompleted: Boolean get() = currentProgress >= targetProgress
}

data class PermanentUpgrades(
  val gold: Int = 150,
  val crystals: Int = 30,
  val highScore: Int = 0,
  val unlockedWave: Int = 1,
  // Gold Training Upgrades
  val baseDamageLevel: Int = 1,
  val baseFireRateLevel: Int = 1,
  val baseFortressHpLevel: Int = 1,
  // Crystal Prestige Talents (permanent cross-run evolution!)
  val crystalPowerLevel: Int = 0,      // +12% all damage per level
  val crystalCritLevel: Int = 0,       // +5% crit chance (2.2x dmg) per level
  val crystalTurretTechLevel: Int = 0, // +15% plant turret damage
  val crystalGateMasteryLevel: Int = 0,// Boosts gate efficiency & barrel damage
  val crystalBountyLevel: Int = 0,     // +15% Gold & Crystal drops per level
  val soundEnabled: Boolean = true,
  val hapticsEnabled: Boolean = true
) {
  val startingBulletDamage: Int
    get() {
      val raw = 48 + (baseDamageLevel - 1) * 10
      val mult = 1.0f + crystalPowerLevel * 0.12f
      return (raw * mult).toInt()
    }

  val startingFireRateMultiplier: Float
    get() = 1.0f + (baseFireRateLevel - 1) * 0.08f

  val startingMaxBaseHp: Int
    get() = 1000 + (baseFortressHpLevel - 1) * 150

  val critChance: Float
    get() = (0.06f + crystalCritLevel * 0.05f).coerceAtMost(0.60f)

  val plantDamageMultiplier: Float
    get() = 1.0f + crystalTurretTechLevel * 0.15f

  val barrelBreakerPower: Int
    get() = 1 + (crystalGateMasteryLevel / 2)

  val leftMultiplier: Int
    get() = (3 + (crystalGateMasteryLevel + 1) / 2).coerceIn(3, 5)

  val rightMultiplier: Int
    get() = (2 + crystalGateMasteryLevel / 2).coerceIn(2, 4)

  val bountyMultiplier: Float
    get() = 1.0f + crystalBountyLevel * 0.15f

  val totalUpgradeLevels: Int
    get() = (baseDamageLevel - 1) + (baseFireRateLevel - 1) + (baseFortressHpLevel - 1) +
      crystalPowerLevel + crystalCritLevel + crystalTurretTechLevel +
      crystalGateMasteryLevel + crystalBountyLevel
}

enum class GameStatus {
  PLAYING,
  PAUSED,
  WAVE_VICTORY,
  GAME_OVER
}

data class BridgeGameUiState(
  val currentScreen: AppScreen = AppScreen.MAIN_MENU,
  val gameMode: GameMode = GameMode.ENDLESS,
  val waveNumber: Int = 1,
  val endlessThreatLevel: Int = 1,
  val endlessElapsedSec: Float = 0f,
  val runGoldEarned: Int = 0,
  val runCrystalsEarned: Int = 0,
  val status: GameStatus = GameStatus.PLAYING,
  val playerX: Float = 0.50f,
  val squadCount: Int = 2,
  val bulletStreams: Int = 2,
  val bulletDamage: Int = 48,
  val fireRateMultiplier: Float = 1.0f,
  val leftGateMultiplier: Int = 3,
  val rightGateMultiplier: Int = 2,
  val baseHp: Int = 1000,
  val maxBaseHp: Int = 1000,
  val score: Int = 0,
  val zombiesRemainingInWave: Int = 90,
  val totalZombiesInWave: Int = 90,
  val zombiesKilledInRun: Int = 0,
  val gameSpeedMultiplier: Float = 1.0f,
  val autoPilotEnabled: Boolean = false,
  val leftBarrels: List<LeftBarrel> = emptyList(),
  val activeTurrets: List<ActiveTurret> = emptyList(),
  val rightBarrels: List<RightBarrel> = emptyList(),
  val zombies: List<Zombie> = emptyList(),
  val projectiles: List<Projectile> = emptyList(),
  val floatingTexts: List<FloatingText> = emptyList(),
  val particles: List<VisualParticle> = emptyList(),
  val muzzleFlashIntensity: Float = 0f,
  val dangerFlashIntensity: Float = 0f,
  val permanentUpgrades: PermanentUpgrades = PermanentUpgrades(),
  val playerStats: PlayerStats = PlayerStats(),
  val showArmorySheet: Boolean = false,
  val showStatsSheet: Boolean = false,
  val showCompendiumSheet: Boolean = false,
  val showSettingsSheet: Boolean = false
)
