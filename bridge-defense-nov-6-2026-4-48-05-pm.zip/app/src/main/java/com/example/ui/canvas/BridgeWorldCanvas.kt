package com.example.ui.canvas

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.testTag
import com.example.model.BridgeGameUiState
import com.example.model.Projectile
import com.example.model.ProjectileStyle
import com.example.ui.canvas.EntityDrawers.drawActiveTurret
import com.example.ui.canvas.EntityDrawers.drawCapybaraCrocodileSquad
import com.example.ui.canvas.EntityDrawers.drawLeftBarrelWithPlant
import com.example.ui.canvas.EntityDrawers.drawOutlinedText
import com.example.ui.canvas.EntityDrawers.drawRightBarrelWithUpgrade
import com.example.ui.canvas.EntityDrawers.drawZombie

@Composable
fun BridgeWorldCanvas(
  uiState: BridgeGameUiState,
  onPlayerMove: (Float) -> Unit,
  modifier: Modifier = Modifier
) {
  Canvas(
    modifier = modifier
      .fillMaxSize()
      .testTag("bridge_game_canvas")
      .pointerInput(Unit) {
        detectTapGestures { offset ->
          if (size.width > 0) {
            onPlayerMove(offset.x / size.width.toFloat())
          }
        }
      }
      .pointerInput(Unit) {
        detectDragGestures { change, _ ->
          change.consume()
          if (size.width > 0) {
            onPlayerMove(change.position.x / size.width.toFloat())
          }
        }
      }
  ) {
    val w = size.width
    val h = size.height

    // 1. Scenic River & Grass Valley Background + Stone Paved Bridge
    drawBridgeEnvironment(w, h)

    // 2. Wooden Log Fences Dividing Left Lane (0..0.27), Center Lane (0.27..0.73), Right Lane (0.73..1.0)
    drawWoodenLogFences(w, h)

    // 3. Yellow & Black Hazard Tape ("/// ⚠ ОПАСНОСТЬ ⚠ ///") at y = 0.64f
    drawHazardTape(w, h, uiState.dangerFlashIntensity)

    // 4. Left Lane Plant Barrels (sorted top to bottom)
    for (barrel in uiState.leftBarrels.sortedBy { it.y }) {
      drawLeftBarrelWithPlant(barrel, w, h)
    }

    // 5. Mounted Active Plant Turrets on Left Fence
    for (turret in uiState.activeTurrets) {
      drawActiveTurret(turret, w, h)
    }

    // 6. Right Lane Weapon & Squad Upgrade Barrels (sorted top to bottom)
    for (barrel in uiState.rightBarrels.sortedBy { it.y }) {
      drawRightBarrelWithUpgrade(barrel, w, h)
    }

    // 7. Dense Zombie Horde in Center Lane (sorted by Y so closer rows overlap back rows)
    for (zombie in uiState.zombies.sortedBy { it.y }) {
      drawZombie(zombie, w, h)
    }

    // 8. Left (X3) and Right (X2) Multiplier Gates at y = 0.50f
    drawMultiplierGates(
      w = w,
      h = h,
      leftMult = uiState.leftGateMultiplier,
      rightMult = uiState.rightGateMultiplier
    )

    // 9. Bullets, Multiplied Blue Bolts, Fiery X2 Bolts, and Plant Projectiles
    for (proj in uiState.projectiles) {
      drawProjectile(proj, w, h)
    }

    // 10. Visual Particles
    for (particle in uiState.particles) {
      drawCircle(
        color = Color(particle.colorHex).copy(alpha = particle.alpha),
        radius = particle.radius,
        center = Offset(particle.x * w, particle.y * h)
      )
    }

    // 11. Player Squad: Capybara Cowboy Riders on Crocodiles!
    drawCapybaraCrocodileSquad(
      playerX = uiState.playerX,
      squadCount = uiState.squadCount,
      muzzleFlash = uiState.muzzleFlashIntensity,
      canvasW = w,
      canvasH = h
    )

    // 12. Floating Upgrade & Hit Popups
    for (ft in uiState.floatingTexts) {
      drawOutlinedText(
        text = ft.text,
        x = ft.x * w,
        y = ft.y * h,
        textSizePx = (w * 0.042f) * ft.scale,
        fillColor = ft.colorHex.toInt()
      )
    }
  }
}

private fun DrawScope.drawBridgeEnvironment(w: Float, h: Float) {
  // Base warm sandstone bridge pavement
  drawRect(
    brush = Brush.verticalGradient(
      colors = listOf(Color(0xFFE7D5B4), Color(0xFFF3E5C8), Color(0xFFE5D2B0))
    ),
    size = Size(w, h)
  )

  // Subtle stone tile grid seams on the bridge
  val rows = 14
  for (r in 1 until rows) {
    val y = (r.toFloat() / rows) * h
    drawLine(
      color = Color(0x55C8B28E),
      start = Offset(0f, y),
      end = Offset(w, y),
      strokeWidth = 2f
    )
    val stagger = if (r % 2 == 0) 0.15f else 0.35f
    drawLine(
      color = Color(0x44C8B28E),
      start = Offset(w * stagger, y - h / rows),
      end = Offset(w * stagger, y),
      strokeWidth = 2f
    )
    drawLine(
      color = Color(0x44C8B28E),
      start = Offset(w * (stagger + 0.35f), y - h / rows),
      end = Offset(w * (stagger + 0.35f), y),
      strokeWidth = 2f
    )
  }

  // Lush Green Grass Banks along the far left and far right perspectives (matching screenshot!)
  val leftGrassPath = Path().apply {
    moveTo(0f, 0f)
    lineTo(w * 0.13f, 0f)
    lineTo(w * 0.02f, h * 0.52f)
    lineTo(0f, h * 0.52f)
    close()
  }
  drawPath(leftGrassPath, color = Color(0xFF84CC16))

  val rightGrassPath = Path().apply {
    moveTo(w, 0f)
    lineTo(w * 0.87f, 0f)
    lineTo(w * 0.98f, h * 0.52f)
    lineTo(w, h * 0.52f)
    close()
  }
  drawPath(rightGrassPath, color = Color(0xFF84CC16))
}

private fun DrawScope.drawWoodenLogFences(w: Float, h: Float) {
  val fenceColumns = listOf(0.27f, 0.73f)
  val gateY = h * 0.465f
  val postCount = 13
  val postH = gateY / postCount
  val postW = w * 0.032f

  for (colNorm in fenceColumns) {
    for (i in 0 until postCount) {
      val py = i * postH
      // Slight perspective taper from top to gate
      val perspectiveShift = (0.5f - colNorm) * (1f - i.toFloat() / postCount) * 0.045f * w
      val px = colNorm * w + perspectiveShift - postW / 2f

      drawRoundRect(
        color = Color(0xFF9A5B32),
        topLeft = Offset(px, py),
        size = Size(postW, postH * 0.92f),
        cornerRadius = CornerRadius(6f)
      )
      drawRoundRect(
        color = Color(0xFF5C3418),
        topLeft = Offset(px, py),
        size = Size(postW, postH * 0.92f),
        cornerRadius = CornerRadius(6f),
        style = Stroke(width = 2f)
      )
      // Top log grain cap
      drawOval(
        color = Color(0xFFD6A87C),
        topLeft = Offset(px + 2f, py + 2f),
        size = Size(postW - 4f, postW * 0.55f)
      )
    }
  }
}

private fun DrawScope.drawMultiplierGates(
  w: Float,
  h: Float,
  leftMult: Int,
  rightMult: Int
) {
  val gateTop = h * 0.468f
  val gateH = h * 0.068f

  // --- LEFT GATE (X3 Blue Multiplier Gate) ---
  val leftGateX = w * 0.025f
  val leftGateW = w * 0.235f
  drawRoundRect(
    brush = Brush.verticalGradient(
      colors = listOf(Color(0xFF38BDF8), Color(0xFF0284C7), Color(0xFF0369A1)),
      startY = gateTop,
      endY = gateTop + gateH
    ),
    topLeft = Offset(leftGateX, gateTop),
    size = Size(leftGateW, gateH),
    cornerRadius = CornerRadius(8f)
  )
  drawRoundRect(
    color = Color(0xFFBAE6FD),
    topLeft = Offset(leftGateX, gateTop),
    size = Size(leftGateW, gateH),
    cornerRadius = CornerRadius(8f),
    style = Stroke(width = 3f)
  )
  // Wooden gate posts on left & right of Left Gate
  drawGateWoodenPost(x = leftGateX - w * 0.015f, y = gateTop - 6f, postW = w * 0.032f, postH = gateH + 12f)
  drawGateWoodenPost(x = leftGateX + leftGateW - w * 0.015f, y = gateTop - 6f, postW = w * 0.032f, postH = gateH + 12f)

  drawOutlinedText(
    text = "X$leftMult",
    x = leftGateX + leftGateW / 2f,
    y = gateTop + gateH * 0.66f,
    textSizePx = gateH * 0.56f
  )

  // --- RIGHT GATE (X2 Glowing Cyan Multiplier Gate) ---
  val rightGateX = w * 0.74f
  val rightGateW = w * 0.235f
  drawRoundRect(
    brush = Brush.radialGradient(
      colors = listOf(Color(0xFFE0F2FE), Color(0xFF67E8F9), Color(0xFF06B6D4)),
      center = Offset(rightGateX + rightGateW / 2f, gateTop + gateH / 2f),
      radius = rightGateW * 0.65f
    ),
    topLeft = Offset(rightGateX, gateTop),
    size = Size(rightGateW, gateH),
    cornerRadius = CornerRadius(8f)
  )
  drawRoundRect(
    color = Color(0xFF0891B2),
    topLeft = Offset(rightGateX, gateTop),
    size = Size(rightGateW, gateH),
    cornerRadius = CornerRadius(8f),
    style = Stroke(width = 3f)
  )
  drawGateWoodenPost(x = rightGateX - w * 0.015f, y = gateTop - 6f, postW = w * 0.032f, postH = gateH + 12f)
  drawGateWoodenPost(x = rightGateX + rightGateW - w * 0.015f, y = gateTop - 6f, postW = w * 0.032f, postH = gateH + 12f)

  drawOutlinedText(
    text = "X$rightMult",
    x = rightGateX + rightGateW / 2f,
    y = gateTop + gateH * 0.66f,
    textSizePx = gateH * 0.56f
  )
}

private fun DrawScope.drawGateWoodenPost(x: Float, y: Float, postW: Float, postH: Float) {
  drawRoundRect(
    color = Color(0xFF854D27),
    topLeft = Offset(x, y),
    size = Size(postW, postH),
    cornerRadius = CornerRadius(6f)
  )
  drawRoundRect(
    color = Color(0xFF431407),
    topLeft = Offset(x, y),
    size = Size(postW, postH),
    cornerRadius = CornerRadius(6f),
    style = Stroke(width = 2f)
  )
}

private fun DrawScope.drawHazardTape(w: Float, h: Float, dangerFlash: Float) {
  val tapeY = h * 0.642f
  val tapeH = h * 0.016f

  // Red danger glow if zombies crossed recently
  if (dangerFlash > 0.05f) {
    drawRect(
      color = Color(0xFFEF4444).copy(alpha = dangerFlash * 0.35f),
      topLeft = Offset(0f, tapeY - tapeH * 2f),
      size = Size(w, tapeH * 5f)
    )
  }

  // Yellow tape background
  drawRect(
    color = Color(0xFFFACC15),
    topLeft = Offset(0f, tapeY),
    size = Size(w, tapeH)
  )

  // Black diagonal hazard stripes along the tape
  val stripeSpacing = w * 0.035f
  var sx = 0f
  while (sx < w) {
    drawLine(
      color = Color(0xFF1E293B),
      start = Offset(sx, tapeY + tapeH),
      end = Offset(sx + stripeSpacing * 0.35f, tapeY),
      strokeWidth = 3.5f
    )
    sx += stripeSpacing
  }
}

private fun DrawScope.drawProjectile(proj: Projectile, w: Float, h: Float) {
  val px = proj.x * w
  val py = proj.y * h

  when (proj.style) {
    ProjectileStyle.STANDARD_BULLET -> {
      drawOval(
        color = Color(0xFFF97316),
        topLeft = Offset(px - 5f, py - 14f),
        size = Size(10f, 28f)
      )
      drawOval(
        color = Color(0xFFFEF08A),
        topLeft = Offset(px - 2.5f, py - 10f),
        size = Size(5f, 18f)
      )
    }

    ProjectileStyle.CRIT_BULLET -> {
      drawOval(
        color = Color(0xFFEF4444),
        topLeft = Offset(px - 7f, py - 18f),
        size = Size(14f, 34f)
      )
      drawOval(
        color = Color.White,
        topLeft = Offset(px - 3.5f, py - 12f),
        size = Size(7f, 22f)
      )
    }

    ProjectileStyle.RIGHT_GATE_FIRE -> {
      // Fiery multiplied orange-red flame bolt (like bullets above the X2 gate in screenshot!)
      drawOval(
        color = Color(0xFFEA580C),
        topLeft = Offset(px - 7f, py - 18f),
        size = Size(14f, 34f)
      )
      drawOval(
        color = Color(0xFFFDE047),
        topLeft = Offset(px - 4f, py - 14f),
        size = Size(8f, 22f)
      )
    }

    ProjectileStyle.LEFT_GATE_BLUE -> {
      // Multiplied X3 cyan-blue energy bolt
      drawOval(
        color = Color(0xFF0284C7),
        topLeft = Offset(px - 6.5f, py - 16f),
        size = Size(13f, 30f)
      )
      drawOval(
        color = Color(0xFFE0F2FE),
        topLeft = Offset(px - 3.5f, py - 12f),
        size = Size(7f, 20f)
      )
    }

    ProjectileStyle.PLANT_SEED -> {
      drawCircle(color = Color(0xFF22C55E), radius = 8f, center = Offset(px, py))
      drawCircle(color = Color(0xFFDCFCE7), radius = 4f, center = Offset(px, py))
    }

    ProjectileStyle.EGGPLANT_BOMB -> {
      drawCircle(color = Color(0xFF9333EA), radius = 12f, center = Offset(px, py))
      drawCircle(color = Color(0xFFE9D5FF), radius = 6f, center = Offset(px, py))
    }

    ProjectileStyle.SOLAR_FLARE -> {
      drawCircle(color = Color(0xFFF59E0B), radius = 11f, center = Offset(px, py))
      drawCircle(color = Color.White, radius = 5f, center = Offset(px, py))
    }

    ProjectileStyle.FROST_SHARD -> {
      drawCircle(color = Color(0xFF0EA5E9), radius = 10f, center = Offset(px, py))
      drawCircle(color = Color(0xFFE0F2FE), radius = 5f, center = Offset(px, py))
    }
  }
}
