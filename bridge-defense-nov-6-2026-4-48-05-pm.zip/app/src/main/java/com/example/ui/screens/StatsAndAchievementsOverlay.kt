package com.example.ui.screens

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.EmojiEvents
import androidx.compose.material.icons.filled.QueryStats
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.AchievementDef
import com.example.model.PlayerStats

@Composable
fun StatsAndAchievementsOverlay(
  stats: PlayerStats,
  achievements: List<AchievementDef>,
  onClaimAchievement: (String) -> Unit,
  onDismiss: () -> Unit
) {
  BackHandler(onBack = onDismiss)
  var selectedTab by remember { mutableIntStateOf(0) } // 0 = Достижения, 1 = Статистика

  Box(
    modifier = Modifier
      .fillMaxSize()
      .background(Color(0xC80F172A))
      .padding(16.dp),
    contentAlignment = Alignment.Center
  ) {
    Card(
      modifier = Modifier
        .fillMaxWidth()
        .widthIn(max = 520.dp)
        .border(2.dp, Color(0xFFA855F7), RoundedCornerShape(24.dp)),
      shape = RoundedCornerShape(24.dp),
      colors = CardDefaults.cardColors(containerColor = Color(0xFF1E293B))
    ) {
      Column(
        modifier = Modifier
          .padding(20.dp)
          .verticalScroll(rememberScrollState()),
        verticalArrangement = Arrangement.spacedBy(12.dp)
      ) {
        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.SpaceBetween,
          verticalAlignment = Alignment.CenterVertically
        ) {
          Text(
            text = "Достижения и Статистика",
            style = MaterialTheme.typography.titleLarge,
            fontWeight = FontWeight.ExtraBold,
            color = Color.White
          )
          IconButton(
            onClick = onDismiss,
            modifier = Modifier
              .size(48.dp)
              .testTag("close_stats_button")
          ) {
            Icon(Icons.Default.Close, contentDescription = "Закрыть", tint = Color.White)
          }
        }

        // Tab Switcher
        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
          Button(
            onClick = { selectedTab = 0 },
            modifier = Modifier
              .weight(1f)
              .height(48.dp)
              .testTag("tab_achievements_button"),
            shape = RoundedCornerShape(14.dp),
            colors = ButtonDefaults.buttonColors(
              containerColor = if (selectedTab == 0) Color(0xFF7C3AED) else Color(0xFF0F172A)
            )
          ) {
            Icon(Icons.Default.EmojiEvents, contentDescription = null, tint = Color(0xFFFACC15))
            Spacer(modifier = Modifier.width(6.dp))
            Text("Достижения", color = Color.White, fontWeight = FontWeight.Bold)
          }

          Button(
            onClick = { selectedTab = 1 },
            modifier = Modifier
              .weight(1f)
              .height(48.dp)
              .testTag("tab_stats_button"),
            shape = RoundedCornerShape(14.dp),
            colors = ButtonDefaults.buttonColors(
              containerColor = if (selectedTab == 1) Color(0xFF0284C7) else Color(0xFF0F172A)
            )
          ) {
            Icon(Icons.Default.QueryStats, contentDescription = null, tint = Color(0xFF38BDF8))
            Spacer(modifier = Modifier.width(6.dp))
            Text("Статистика", color = Color.White, fontWeight = FontWeight.Bold)
          }
        }

        if (selectedTab == 0) {
          Text(
            text = "Выполняйте достижения, чтобы получать Кристаллы Эволюции 💎 для вечной прокачки!",
            color = Color(0xFFCBD5E1),
            fontSize = 12.sp
          )

          for (ach in achievements) {
            AchievementItemCard(
              achievement = ach,
              onClaim = { onClaimAchievement(ach.id) }
            )
          }
        } else {
          val minutes = stats.bestEndlessTimeSec / 60
          val seconds = stats.bestEndlessTimeSec % 60
          val timeFormatted = "%02d:%02d".format(minutes, seconds)

          StatMetricRow("Сыграно боевых вылетов", "${stats.totalRunsPlayed}")
          StatMetricRow("Макс. Уровень Угрозы (Бесконечный)", "Уровень ${stats.bestEndlessThreatLevel}")
          StatMetricRow("Рекорд выживания (Бесконечный)", timeFormatted)
          StatMetricRow("Макс. открытая волна Кампании", "Волна ${stats.highestCampaignWave}")
          StatMetricRow("Рекорд очков за бой", "${stats.bestScore}")
          StatMetricRow("Всего уничтожено зомби", "${stats.totalZombiesKilled}")
          StatMetricRow("Уничтожено Боссов-Титанов", "${stats.totalBossesKilled}")
          StatMetricRow("Уничтожено элитных мутантов", "${stats.totalElitesKilled}")
          StatMetricRow("Разбито бочек растений (слева)", "${stats.totalLeftBarrelsBroken}")
          StatMetricRow("Разбито бочек оружия (справа)", "${stats.totalRightBarrelsBroken}")
          StatMetricRow("Всего добыто Золота 🪙", "${stats.lifetimeGoldEarned} 🪙")
          StatMetricRow("Всего добыто Кристаллов 💎", "${stats.lifetimeCrystalsEarned} 💎")
        }
      }
    }
  }
}

@Composable
private fun AchievementItemCard(
  achievement: AchievementDef,
  onClaim: () -> Unit
) {
  val progressFraction = (achievement.currentProgress.toFloat() / achievement.targetProgress.toFloat())
    .coerceIn(0f, 1f)

  Column(
    modifier = Modifier
      .fillMaxWidth()
      .clip(RoundedCornerShape(16.dp))
      .background(Color(0xFF0F172A))
      .border(
        width = 1.dp,
        color = when {
          achievement.isCompleted && !achievement.isClaimed -> Color(0xFFFACC15)
          achievement.isClaimed -> Color(0xFF22C55E)
          else -> Color(0xFF334155)
        },
        shape = RoundedCornerShape(16.dp)
      )
      .padding(14.dp)
  ) {
    Row(
      modifier = Modifier.fillMaxWidth(),
      horizontalArrangement = Arrangement.SpaceBetween,
      verticalAlignment = Alignment.CenterVertically
    ) {
      Column(modifier = Modifier.weight(1f)) {
        Text(
          text = achievement.titleRu,
          color = Color.White,
          fontWeight = FontWeight.Bold,
          fontSize = 15.sp
        )
        Text(
          text = achievement.descriptionRu,
          color = Color(0xFF94A3B8),
          fontSize = 12.sp
        )
      }
      Spacer(modifier = Modifier.width(8.dp))
      if (achievement.isClaimed) {
        Row(verticalAlignment = Alignment.CenterVertically) {
          Icon(
            imageVector = Icons.Default.CheckCircle,
            contentDescription = "Получено",
            tint = Color(0xFF4ADE80),
            modifier = Modifier.size(20.dp)
          )
          Spacer(modifier = Modifier.width(4.dp))
          Text("Получено", color = Color(0xFF4ADE80), fontSize = 12.sp, fontWeight = FontWeight.Bold)
        }
      } else {
        Button(
          onClick = onClaim,
          enabled = achievement.isCompleted,
          shape = RoundedCornerShape(12.dp),
          colors = ButtonDefaults.buttonColors(
            containerColor = Color(0xFF38BDF8),
            disabledContainerColor = Color(0xFF1E293B)
          ),
          modifier = Modifier.testTag("claim_ach_${achievement.id}")
        ) {
          Text(
            text = if (achievement.isCompleted) "Забрать +${achievement.rewardCrystals} 💎" else "+${achievement.rewardCrystals} 💎",
            color = if (achievement.isCompleted) Color.Black else Color(0xFF94A3B8),
            fontWeight = FontWeight.ExtraBold,
            fontSize = 12.sp
          )
        }
      }
    }

    Spacer(modifier = Modifier.height(8.dp))

    Row(
      modifier = Modifier.fillMaxWidth(),
      verticalAlignment = Alignment.CenterVertically,
      horizontalArrangement = Arrangement.spacedBy(8.dp)
    ) {
      LinearProgressIndicator(
        progress = { progressFraction },
        modifier = Modifier
          .weight(1f)
          .height(8.dp)
          .clip(RoundedCornerShape(4.dp)),
        color = if (achievement.isCompleted) Color(0xFF4ADE80) else Color(0xFF38BDF8),
        trackColor = Color(0xFF1E293B)
      )
      Text(
        text = "${achievement.currentProgress}/${achievement.targetProgress}",
        color = Color(0xFFCBD5E1),
        fontSize = 11.sp,
        fontWeight = FontWeight.Bold
      )
    }
  }
}

@Composable
private fun StatMetricRow(label: String, value: String) {
  Row(
    modifier = Modifier
      .fillMaxWidth()
      .clip(RoundedCornerShape(12.dp))
      .background(Color(0xFF0F172A))
      .padding(horizontal = 14.dp, vertical = 11.dp),
    horizontalArrangement = Arrangement.SpaceBetween,
    verticalAlignment = Alignment.CenterVertically
  ) {
    Text(text = label, color = Color(0xFFCBD5E1), fontSize = 13.sp)
    Text(text = value, color = Color.White, fontWeight = FontWeight.ExtraBold, fontSize = 14.sp)
  }
}
