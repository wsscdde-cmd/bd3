package com.example.ui.screens

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.Bolt
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.EmojiEvents
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.LocalFireDepartment
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Shield
import androidx.compose.material.icons.filled.Speed
import androidx.compose.material.icons.filled.Star
import androidx.compose.material.icons.filled.Vibration
import androidx.compose.material.icons.filled.VolumeUp
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.BridgeGameUiState
import com.example.model.GameMode
import com.example.model.PlantType
import com.example.model.ZombieType

@Composable
fun ArmoryAndSettingsOverlay(
  uiState: BridgeGameUiState,
  onBuyUpgrade: (String) -> Unit,
  onDismiss: () -> Unit
) {
  BackHandler(onBack = onDismiss)
  val perm = uiState.permanentUpgrades
  var selectedCurrencyTab by remember { mutableIntStateOf(0) } // 0 = 💎 Кристаллы (Вечная Эволюция), 1 = 🪙 Золото (База)

  Box(
    modifier = Modifier
      .fillMaxSize()
      .background(Color(0xC80F172A))
      .padding(16.dp),
    contentAlignment = Alignment.Center
  ) {
    Card(
      modifier = Modifier
        .fillMaxWidth()
        .widthIn(max = 520.dp)
        .border(2.dp, Color(0xFF38BDF8), RoundedCornerShape(24.dp)),
      shape = RoundedCornerShape(24.dp),
      colors = CardDefaults.cardColors(containerColor = Color(0xFF1E293B))
    ) {
      Column(
        modifier = Modifier
          .padding(20.dp)
          .verticalScroll(rememberScrollState()),
        verticalArrangement = Arrangement.spacedBy(12.dp)
      ) {
        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.SpaceBetween,
          verticalAlignment = Alignment.CenterVertically
        ) {
          Column {
            Text(
              text = "Вечная Прокачка Отряда",
              style = MaterialTheme.typography.titleLarge,
              fontWeight = FontWeight.ExtraBold,
              color = Color.White
            )
            Text(
              text = "💎 Кристаллы: ${perm.crystals}  •  🪙 Золото: ${perm.gold}",
              style = MaterialTheme.typography.bodyMedium,
              color = Color(0xFF38BDF8),
              fontWeight = FontWeight.ExtraBold
            )
          }
          IconButton(
            onClick = onDismiss,
            modifier = Modifier
              .size(48.dp)
              .testTag("close_armory_button")
          ) {
            Icon(
              imageVector = Icons.Default.Close,
              contentDescription = "Закрыть арсенал",
              tint = Color.White
            )
          }
        }

        // Currency Category Switcher
        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
          Button(
            onClick = { selectedCurrencyTab = 0 },
            modifier = Modifier
              .weight(1f)
              .height(46.dp)
              .testTag("tab_crystal_upgrades"),
            shape = RoundedCornerShape(14.dp),
            colors = ButtonDefaults.buttonColors(
              containerColor = if (selectedCurrencyTab == 0) Color(0xFF0284C7) else Color(0xFF0F172A)
            )
          ) {
            Text("💎 Эволюция (${perm.crystals})", color = Color.White, fontWeight = FontWeight.ExtraBold, fontSize = 13.sp)
          }

          Button(
            onClick = { selectedCurrencyTab = 1 },
            modifier = Modifier
              .weight(1f)
              .height(46.dp)
              .testTag("tab_gold_upgrades"),
            shape = RoundedCornerShape(14.dp),
            colors = ButtonDefaults.buttonColors(
              containerColor = if (selectedCurrencyTab == 1) Color(0xFFD97706) else Color(0xFF0F172A)
            )
          ) {
            Text("🪙 Тренировка (${perm.gold})", color = Color.White, fontWeight = FontWeight.ExtraBold, fontSize = 13.sp)
          }
        }

        if (selectedCurrencyTab == 0) {
          Text(
            text = "Таланты за Кристаллы 💎 сохраняются навсегда после поражения и усиливают каждый ваш новый забег!",
            color = Color(0xFFBAE6FD),
            fontSize = 12.sp
          )

          val powerCost = 15 + perm.crystalPowerLevel * 12
          UpgradeRowItem(
            title = "Калибр Эволюции (Ур. ${perm.crystalPowerLevel})",
            subtitle = "Вечный бонус ко всему урону: +${perm.crystalPowerLevel * 10}% (+10%)",
            costLabel = "$powerCost 💎",
            canAfford = perm.crystals >= powerCost,
            icon = Icons.Default.LocalFireDepartment,
            accentColor = Color(0xFF38BDF8),
            buttonColor = Color(0xFF38BDF8),
            testTag = "buy_crystal_power",
            onClick = { onBuyUpgrade("crystal_power") }
          )

          val critCost = 18 + perm.crystalCritLevel * 14
          UpgradeRowItem(
            title = "Критический Прицел (Ур. ${perm.crystalCritLevel}/10)",
            subtitle = "Шанс 2.2x крит. выстрела: ${(perm.critChance * 100).toInt()}% (+5%)",
            costLabel = if (perm.crystalCritLevel < 10) "$critCost 💎" else "МАКС",
            canAfford = perm.crystals >= critCost && perm.crystalCritLevel < 10,
            icon = Icons.Default.Bolt,
            accentColor = Color(0xFFF43F5E),
            buttonColor = Color(0xFF38BDF8),
            testTag = "buy_crystal_crit",
            onClick = { onBuyUpgrade("crystal_crit") }
          )

          val turretCost = 20 + perm.crystalTurretTechLevel * 15
          UpgradeRowItem(
            title = "Био-Ген Растений (Ур. ${perm.crystalTurretTechLevel}/10)",
            subtitle = "Урон боевых растений слева: +${perm.crystalTurretTechLevel * 15}% (+15%)",
            costLabel = if (perm.crystalTurretTechLevel < 10) "$turretCost 💎" else "МАКС",
            canAfford = perm.crystals >= turretCost && perm.crystalTurretTechLevel < 10,
            icon = Icons.Default.AutoAwesome,
            accentColor = Color(0xFF4ADE80),
            buttonColor = Color(0xFF38BDF8),
            testTag = "buy_crystal_turret",
            onClick = { onBuyUpgrade("crystal_turret") }
          )

          val gateCost = 25 + perm.crystalGateMasteryLevel * 20
          UpgradeRowItem(
            title = "Пробойник Бочек (Ур. ${perm.crystalGateMasteryLevel}/6)",
            subtitle = "Урон по бочкам: ${perm.barrelBreakerPower} • Ворота X${perm.leftMultiplier}/X${perm.rightMultiplier}",
            costLabel = if (perm.crystalGateMasteryLevel < 6) "$gateCost 💎" else "МАКС",
            canAfford = perm.crystals >= gateCost && perm.crystalGateMasteryLevel < 6,
            icon = Icons.Default.Shield,
            accentColor = Color(0xFFA855F7),
            buttonColor = Color(0xFF38BDF8),
            testTag = "buy_crystal_gate",
            onClick = { onBuyUpgrade("crystal_gate") }
          )

          val bountyCost = 20 + perm.crystalBountyLevel * 16
          UpgradeRowItem(
            title = "Искатель Трофеев (Ур. ${perm.crystalBountyLevel}/10)",
            subtitle = "Добыча Золота 🪙 и Кристаллов 💎: +${perm.crystalBountyLevel * 15}%",
            costLabel = if (perm.crystalBountyLevel < 10) "$bountyCost 💎" else "МАКС",
            canAfford = perm.crystals >= bountyCost && perm.crystalBountyLevel < 10,
            icon = Icons.Default.Star,
            accentColor = Color(0xFFFACC15),
            buttonColor = Color(0xFF38BDF8),
            testTag = "buy_crystal_bounty",
            onClick = { onBuyUpgrade("crystal_bounty") }
          )
        } else {
          Text(
            text = "Базовая тренировка за Золото 🪙 повышает стартовые характеристики отряда в начале каждого боя.",
            color = Color(0xFFFDE68A),
            fontSize = 12.sp
          )

          val dmgCost = 80 + (perm.baseDamageLevel - 1) * 65
          UpgradeRowItem(
            title = "Базовый урон пулемёта (Ур. ${perm.baseDamageLevel})",
            subtitle = "Стартовый урон пули: ${perm.startingBulletDamage}",
            costLabel = "$dmgCost 🪙",
            canAfford = perm.gold >= dmgCost,
            icon = Icons.Default.LocalFireDepartment,
            accentColor = Color(0xFFF97316),
            buttonColor = Color(0xFFF59E0B),
            testTag = "buy_gold_damage",
            onClick = { onBuyUpgrade("gold_damage") }
          )

          val fireCost = 95 + (perm.baseFireRateLevel - 1) * 75
          UpgradeRowItem(
            title = "Смазка затвора (Ур. ${perm.baseFireRateLevel}/15)",
            subtitle = "Стартовый темп огня: x${"%.2f".format(perm.startingFireRateMultiplier)} (+6%)",
            costLabel = if (perm.baseFireRateLevel < 15) "$fireCost 🪙" else "МАКС",
            canAfford = perm.gold >= fireCost && perm.baseFireRateLevel < 15,
            icon = Icons.Default.Bolt,
            accentColor = Color(0xFFFACC15),
            buttonColor = Color(0xFFF59E0B),
            testTag = "buy_gold_firerate",
            onClick = { onBuyUpgrade("gold_firerate") }
          )

          val hpCost = 90 + (perm.baseFortressHpLevel - 1) * 70
          UpgradeRowItem(
            title = "Укрепление Базы (Ур. ${perm.baseFortressHpLevel}/15)",
            subtitle = "Прочность моста: ${perm.startingMaxBaseHp} HP (+120 HP)",
            costLabel = if (perm.baseFortressHpLevel < 15) "$hpCost 🪙" else "МАКС",
            canAfford = perm.gold >= hpCost && perm.baseFortressHpLevel < 15,
            icon = Icons.Default.Shield,
            accentColor = Color(0xFF4ADE80),
            buttonColor = Color(0xFFF59E0B),
            testTag = "buy_gold_fortress",
            onClick = { onBuyUpgrade("gold_fortress") }
          )
        }
      }
    }
  }
}

@Composable
private fun UpgradeRowItem(
  title: String,
  subtitle: String,
  costLabel: String,
  canAfford: Boolean,
  icon: ImageVector,
  accentColor: Color,
  buttonColor: Color,
  testTag: String,
  onClick: () -> Unit
) {
  Row(
    modifier = Modifier
      .fillMaxWidth()
      .clip(RoundedCornerShape(16.dp))
      .background(Color(0xFF0F172A))
      .padding(12.dp),
    horizontalArrangement = Arrangement.SpaceBetween,
    verticalAlignment = Alignment.CenterVertically
  ) {
    Row(
      modifier = Modifier.weight(1f),
      verticalAlignment = Alignment.CenterVertically
    ) {
      Box(
        modifier = Modifier
          .size(42.dp)
          .clip(CircleShape)
          .background(accentColor.copy(alpha = 0.2f)),
        contentAlignment = Alignment.Center
      ) {
        Icon(imageVector = icon, contentDescription = null, tint = accentColor)
      }
      Spacer(modifier = Modifier.width(12.dp))
      Column {
        Text(
          text = title,
          color = Color.White,
          fontWeight = FontWeight.Bold,
          fontSize = 14.sp
        )
        Text(
          text = subtitle,
          color = Color(0xFF94A3B8),
          fontSize = 12.sp
        )
      }
    }
    Spacer(modifier = Modifier.width(8.dp))
    Button(
      onClick = onClick,
      enabled = canAfford,
      shape = RoundedCornerShape(12.dp),
      colors = ButtonDefaults.buttonColors(
        containerColor = buttonColor,
        disabledContainerColor = Color(0xFF334155)
      ),
      modifier = Modifier.testTag(testTag)
    ) {
      Text(
        text = costLabel,
        color = if (canAfford) Color.Black else Color(0xFF94A3B8),
        fontWeight = FontWeight.ExtraBold,
        fontSize = 12.sp
      )
    }
  }
}

@Composable
fun SettingsModalOverlay(
  uiState: BridgeGameUiState,
  onToggleSound: () -> Unit,
  onToggleHaptics: () -> Unit,
  onToggleSpeed: () -> Unit,
  onDismiss: () -> Unit
) {
  BackHandler(onBack = onDismiss)
  val perm = uiState.permanentUpgrades

  Box(
    modifier = Modifier
      .fillMaxSize()
      .background(Color(0xC80F172A))
      .padding(20.dp),
    contentAlignment = Alignment.Center
  ) {
    Card(
      modifier = Modifier
        .fillMaxWidth()
        .widthIn(max = 440.dp)
        .border(2.dp, Color(0xFF38BDF8), RoundedCornerShape(24.dp)),
      shape = RoundedCornerShape(24.dp),
      colors = CardDefaults.cardColors(containerColor = Color(0xFF1E293B))
    ) {
      Column(
        modifier = Modifier.padding(22.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
      ) {
        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.SpaceBetween,
          verticalAlignment = Alignment.CenterVertically
        ) {
          Text(
            text = "Настройки Игры",
            style = MaterialTheme.typography.titleLarge,
            fontWeight = FontWeight.ExtraBold,
            color = Color.White
          )
          IconButton(
            onClick = onDismiss,
            modifier = Modifier
              .size(48.dp)
              .testTag("close_settings_button")
          ) {
            Icon(Icons.Default.Close, contentDescription = "Закрыть настройки", tint = Color.White)
          }
        }

        Row(
          modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(14.dp))
            .background(Color(0xFF0F172A))
            .padding(horizontal = 14.dp, vertical = 10.dp),
          horizontalArrangement = Arrangement.SpaceBetween,
          verticalAlignment = Alignment.CenterVertically
        ) {
          Row(verticalAlignment = Alignment.CenterVertically) {
            Icon(Icons.Default.VolumeUp, contentDescription = null, tint = Color(0xFF38BDF8))
            Spacer(modifier = Modifier.width(10.dp))
            Text("Звуковые эффекты", color = Color.White, fontWeight = FontWeight.SemiBold)
          }
          Switch(
            checked = perm.soundEnabled,
            onCheckedChange = { onToggleSound() },
            modifier = Modifier.testTag("toggle_sound_switch")
          )
        }

        Row(
          modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(14.dp))
            .background(Color(0xFF0F172A))
            .padding(horizontal = 14.dp, vertical = 10.dp),
          horizontalArrangement = Arrangement.SpaceBetween,
          verticalAlignment = Alignment.CenterVertically
        ) {
          Row(verticalAlignment = Alignment.CenterVertically) {
            Icon(Icons.Default.Vibration, contentDescription = null, tint = Color(0xFF4ADE80))
            Spacer(modifier = Modifier.width(10.dp))
            Text("Тактильная вибрация", color = Color.White, fontWeight = FontWeight.SemiBold)
          }
          Switch(
            checked = perm.hapticsEnabled,
            onCheckedChange = { onToggleHaptics() },
            modifier = Modifier.testTag("toggle_haptics_switch")
          )
        }

        Row(
          modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(14.dp))
            .background(Color(0xFF0F172A))
            .padding(horizontal = 14.dp, vertical = 10.dp),
          horizontalArrangement = Arrangement.SpaceBetween,
          verticalAlignment = Alignment.CenterVertically
        ) {
          Row(verticalAlignment = Alignment.CenterVertically) {
            Icon(Icons.Default.Speed, contentDescription = null, tint = Color(0xFFFACC15))
            Spacer(modifier = Modifier.width(10.dp))
            Text("Ускоренный темп (1.5x)", color = Color.White, fontWeight = FontWeight.SemiBold)
          }
          Switch(
            checked = uiState.gameSpeedMultiplier > 1.2f,
            onCheckedChange = { onToggleSpeed() },
            modifier = Modifier.testTag("toggle_speed_switch")
          )
        }

        Button(
          onClick = onDismiss,
          modifier = Modifier
            .fillMaxWidth()
            .height(48.dp),
          shape = RoundedCornerShape(14.dp),
          colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF0284C7))
        ) {
          Text("Готово", color = Color.White, fontWeight = FontWeight.ExtraBold)
        }
      }
    }
  }
}

@Composable
fun CompendiumOverlay(
  onDismiss: () -> Unit
) {
  BackHandler(onBack = onDismiss)

  Box(
    modifier = Modifier
      .fillMaxSize()
      .background(Color(0xC80F172A))
      .padding(16.dp),
    contentAlignment = Alignment.Center
  ) {
    Card(
      modifier = Modifier
        .fillMaxWidth()
        .widthIn(max = 520.dp)
        .border(2.dp, Color(0xFF38BDF8), RoundedCornerShape(24.dp)),
      shape = RoundedCornerShape(24.dp),
      colors = CardDefaults.cardColors(containerColor = Color(0xFF1E293B))
    ) {
      Column(
        modifier = Modifier
          .padding(20.dp)
          .verticalScroll(rememberScrollState()),
        verticalArrangement = Arrangement.spacedBy(12.dp)
      ) {
        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.SpaceBetween,
          verticalAlignment = Alignment.CenterVertically
        ) {
          Text(
            text = "Бестиарий и Растения",
            style = MaterialTheme.typography.titleLarge,
            fontWeight = FontWeight.ExtraBold,
            color = Color.White
          )
          IconButton(
            onClick = onDismiss,
            modifier = Modifier
              .size(48.dp)
              .testTag("close_compendium_button")
          ) {
            Icon(Icons.Default.Close, contentDescription = "Закрыть справочник", tint = Color.White)
          }
        }

        Text(
          text = "Боевые Растения (Левая Полоса):",
          color = Color(0xFF4ADE80),
          fontWeight = FontWeight.Bold,
          fontSize = 15.sp
        )

        for (plant in PlantType.entries) {
          Column(
            modifier = Modifier
              .fillMaxWidth()
              .clip(RoundedCornerShape(14.dp))
              .background(Color(0xFF0F172A))
              .padding(12.dp)
          ) {
            Row(
              modifier = Modifier.fillMaxWidth(),
              horizontalArrangement = Arrangement.SpaceBetween
            ) {
              Text(plant.titleRu, color = Color.White, fontWeight = FontWeight.Bold)
              Text(
                text = "Урон: ${plant.baseDamage} • Бочка: ${plant.baseHitsRequired}",
                color = Color(0xFF38BDF8),
                fontSize = 12.sp,
                fontWeight = FontWeight.SemiBold
              )
            }
            Spacer(modifier = Modifier.height(4.dp))
            Text(plant.descriptionRu, color = Color(0xFF94A3B8), fontSize = 12.sp)
          }
        }

        Text(
          text = "Виды Врагов и Мутантов (Бесконечная Орда):",
          color = Color(0xFFF87171),
          fontWeight = FontWeight.Bold,
          fontSize = 15.sp
        )

        for (zType in ZombieType.entries) {
          Column(
            modifier = Modifier
              .fillMaxWidth()
              .clip(RoundedCornerShape(12.dp))
              .background(Color(0xFF0F172A))
              .padding(10.dp)
          ) {
            Row(
              modifier = Modifier.fillMaxWidth(),
              horizontalArrangement = Arrangement.SpaceBetween
            ) {
              Text(
                text = "${zType.nameRu} (с Угрозы ${zType.minThreatLevel})",
                color = Color.White,
                fontWeight = FontWeight.Bold,
                fontSize = 13.sp
              )
              Text(
                text = "HP x${zType.hpMultiplier} • +${zType.goldReward} 🪙",
                color = Color(0xFFFACC15),
                fontSize = 12.sp,
                fontWeight = FontWeight.Bold
              )
            }
            Text(zType.descriptionRu, color = Color(0xFF94A3B8), fontSize = 11.sp)
          }
        }
      }
    }
  }
}

@Composable
fun PauseDialogOverlay(
  uiState: BridgeGameUiState,
  onResume: () -> Unit,
  onRestart: () -> Unit,
  onOpenArmory: () -> Unit,
  onReturnToMainMenu: () -> Unit
) {
  BackHandler(onBack = onResume)

  Box(
    modifier = Modifier
      .fillMaxSize()
      .background(Color(0xB80F172A))
      .padding(24.dp),
    contentAlignment = Alignment.Center
  ) {
    Card(
      modifier = Modifier
        .fillMaxWidth()
        .widthIn(max = 400.dp)
        .border(2.dp, Color(0xFF38BDF8), RoundedCornerShape(24.dp)),
      shape = RoundedCornerShape(24.dp),
      colors = CardDefaults.cardColors(containerColor = Color(0xFF1E293B))
    ) {
      Column(
        modifier = Modifier.padding(24.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.spacedBy(12.dp)
      ) {
        Text(
          text = if (uiState.gameMode == GameMode.ENDLESS) {
            "Пауза • Угроза Ур. ${uiState.endlessThreatLevel}"
          } else {
            "Пауза • Волна ${uiState.waveNumber}"
          },
          style = MaterialTheme.typography.headlineSmall,
          fontWeight = FontWeight.ExtraBold,
          color = Color.White
        )
        Text(
          text = "Забег: +${uiState.runGoldEarned} 🪙  •  +${uiState.runCrystalsEarned} 💎",
          color = Color(0xFFFACC15),
          fontWeight = FontWeight.Bold
        )

        Button(
          onClick = onResume,
          modifier = Modifier
            .fillMaxWidth()
            .height(50.dp)
            .testTag("resume_game_button"),
          shape = RoundedCornerShape(14.dp),
          colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF22C55E))
        ) {
          Icon(Icons.Default.PlayArrow, contentDescription = null, tint = Color.Black)
          Spacer(modifier = Modifier.width(8.dp))
          Text("Продолжить Бой", color = Color.Black, fontWeight = FontWeight.ExtraBold)
        }

        Button(
          onClick = onOpenArmory,
          modifier = Modifier
            .fillMaxWidth()
            .height(50.dp)
            .testTag("pause_open_armory_button"),
          shape = RoundedCornerShape(14.dp),
          colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF0284C7))
        ) {
          Text("Вечная Прокачка (💎 / 🪙)", color = Color.White, fontWeight = FontWeight.ExtraBold)
        }

        OutlinedButton(
          onClick = onRestart,
          modifier = Modifier
            .fillMaxWidth()
            .height(48.dp)
            .testTag("restart_wave_button"),
          shape = RoundedCornerShape(14.dp)
        ) {
          Icon(Icons.Default.Refresh, contentDescription = null, tint = Color.White)
          Spacer(modifier = Modifier.width(8.dp))
          Text("Начать Заново", color = Color.White, fontWeight = FontWeight.Bold)
        }

        OutlinedButton(
          onClick = onReturnToMainMenu,
          modifier = Modifier
            .fillMaxWidth()
            .height(48.dp)
            .testTag("pause_main_menu_button"),
          shape = RoundedCornerShape(14.dp)
        ) {
          Icon(Icons.Default.Home, contentDescription = null, tint = Color(0xFF38BDF8))
          Spacer(modifier = Modifier.width(8.dp))
          Text("В Главное Меню", color = Color(0xFFBAE6FD), fontWeight = FontWeight.Bold)
        }
      }
    }
  }
}

@Composable
fun WaveResultOverlay(
  isVictory: Boolean,
  uiState: BridgeGameUiState,
  onPrimaryAction: () -> Unit,
  onOpenArmory: () -> Unit,
  onReturnToMainMenu: () -> Unit
) {
  Box(
    modifier = Modifier
      .fillMaxSize()
      .background(Color(0xC80F172A))
      .padding(24.dp),
    contentAlignment = Alignment.Center
  ) {
    val accent = if (isVictory) Color(0xFF22C55E) else Color(0xFFEF4444)
    val perm = uiState.permanentUpgrades
    Card(
      modifier = Modifier
        .fillMaxWidth()
        .widthIn(max = 430.dp)
        .border(3.dp, accent, RoundedCornerShape(26.dp)),
      shape = RoundedCornerShape(26.dp),
      colors = CardDefaults.cardColors(containerColor = Color(0xFF1E293B))
    ) {
      Column(
        modifier = Modifier.padding(24.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.spacedBy(12.dp)
      ) {
        Icon(
          imageVector = if (isVictory) Icons.Default.EmojiEvents else Icons.Default.Shield,
          contentDescription = null,
          tint = accent,
          modifier = Modifier.size(52.dp)
        )
        Text(
          text = when {
            isVictory -> "Волна ${uiState.waveNumber} Отражена!"
            uiState.gameMode == GameMode.ENDLESS -> "Бесконечный Бой Окончен!\nУровень Угрозы: ${uiState.endlessThreatLevel}"
            else -> "Зомби Прорвали Мост!"
          },
          style = MaterialTheme.typography.titleLarge,
          fontWeight = FontWeight.ExtraBold,
          color = Color.White,
          textAlign = TextAlign.Center
        )

        Column(
          modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(14.dp))
            .background(Color(0xFF0F172A))
            .padding(12.dp),
          horizontalAlignment = Alignment.CenterHorizontally,
          verticalArrangement = Arrangement.spacedBy(4.dp)
        ) {
          Text(
            text = "Убито зомби за вылет: ${uiState.zombiesKilledInRun} • Счёт: ${uiState.score}",
            color = Color(0xFFE2E8F0),
            fontSize = 13.sp,
            fontWeight = FontWeight.SemiBold
          )
          Text(
            text = "Добыто за бой: +${uiState.runGoldEarned} 🪙  и  +${uiState.runCrystalsEarned} 💎",
            color = Color(0xFFFACC15),
            fontWeight = FontWeight.ExtraBold,
            fontSize = 15.sp
          )
          Text(
            text = "Всего в казне: ${perm.gold} 🪙 • ${perm.crystals} 💎",
            color = Color(0xFF38BDF8),
            fontWeight = FontWeight.Bold,
            fontSize = 13.sp
          )
        }

        Button(
          onClick = onOpenArmory,
          modifier = Modifier
            .fillMaxWidth()
            .height(50.dp)
            .testTag("result_open_armory_button"),
          shape = RoundedCornerShape(14.dp),
          colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF0284C7))
        ) {
          Icon(Icons.Default.AutoAwesome, contentDescription = null, tint = Color(0xFFFDE047))
          Spacer(modifier = Modifier.width(8.dp))
          Text(
            text = "Прокачать Таланты (${perm.crystals} 💎 / ${perm.gold} 🪙)",
            color = Color.White,
            fontWeight = FontWeight.ExtraBold,
            fontSize = 13.sp
          )
        }

        Button(
          onClick = onPrimaryAction,
          modifier = Modifier
            .fillMaxWidth()
            .height(50.dp)
            .testTag(if (isVictory) "next_wave_button" else "retry_wave_button"),
          shape = RoundedCornerShape(14.dp),
          colors = ButtonDefaults.buttonColors(containerColor = accent)
        ) {
          Text(
            text = if (isVictory) "Следующая Волна (${uiState.waveNumber + 1})" else "Новый Забег (С Усилениями!)",
            color = if (isVictory) Color.Black else Color.White,
            fontWeight = FontWeight.ExtraBold,
            fontSize = 15.sp
          )
        }

        OutlinedButton(
          onClick = onReturnToMainMenu,
          modifier = Modifier
            .fillMaxWidth()
            .height(46.dp)
            .testTag("result_main_menu_button"),
          shape = RoundedCornerShape(14.dp)
        ) {
          Text("В Главное Меню", color = Color.White, fontWeight = FontWeight.Bold)
        }
      }
    }
  }
}
