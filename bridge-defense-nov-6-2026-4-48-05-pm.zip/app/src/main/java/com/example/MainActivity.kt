package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Scaffold
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.audio.SoundAndHapticsManager
import com.example.data.GamePreferencesRepository
import com.example.ui.screens.BridgeGameScreen
import com.example.ui.theme.MyApplicationTheme
import com.example.viewmodel.BridgeGameViewModel

class MainActivity : ComponentActivity() {
  override fun onCreate(savedInstanceState: Bundle?) {
    super.onCreate(savedInstanceState)
    enableEdgeToEdge()
    setContent {
      MyApplicationTheme {
        val context = LocalContext.current
        val repository = remember { GamePreferencesRepository(context.applicationContext) }
        val soundManager = remember { SoundAndHapticsManager(context.applicationContext) }
        val gameViewModel: BridgeGameViewModel = viewModel(
          factory = BridgeGameViewModel.Factory(repository, soundManager)
        )
        val uiState by gameViewModel.uiState.collectAsStateWithLifecycle()

        Scaffold(
          modifier = Modifier.fillMaxSize(),
          contentWindowInsets = WindowInsets(0.dp, 0.dp, 0.dp, 0.dp)
        ) { innerPadding ->
          BridgeGameScreen(
            uiState = uiState,
            viewModel = gameViewModel,
            modifier = Modifier
              .fillMaxSize()
              .padding(innerPadding)
          )
        }
      }
    }
  }
}
