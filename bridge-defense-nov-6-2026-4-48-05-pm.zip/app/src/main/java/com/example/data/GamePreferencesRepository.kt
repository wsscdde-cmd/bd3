package com.example.data

import android.content.Context
import android.content.SharedPreferences
import com.example.model.AchievementDef
import com.example.model.PermanentUpgrades
import com.example.model.PlayerStats

class GamePreferencesRepository(context: Context) {
  private val prefs: SharedPreferences =
    context.getSharedPreferences("bridge_defense_prefs_v2", Context.MODE_PRIVATE)

  fun loadUpgrades(): PermanentUpgrades {
    return PermanentUpgrades(
      gold = prefs.getInt(KEY_GOLD, 150),
      crystals = prefs.getInt(KEY_CRYSTALS, 30),
      highScore = prefs.getInt(KEY_HIGH_SCORE, 0),
      unlockedWave = prefs.getInt(KEY_UNLOCKED_WAVE, 1),
      baseDamageLevel = prefs.getInt(KEY_DAMAGE_LEVEL, 1),
      baseFireRateLevel = prefs.getInt(KEY_FIRE_RATE_LEVEL, 1),
      baseFortressHpLevel = prefs.getInt(KEY_FORTRESS_HP_LEVEL, 1),
      crystalPowerLevel = prefs.getInt(KEY_CRYSTAL_POWER, 0),
      crystalCritLevel = prefs.getInt(KEY_CRYSTAL_CRIT, 0),
      crystalTurretTechLevel = prefs.getInt(KEY_CRYSTAL_TURRET, 0),
      crystalGateMasteryLevel = prefs.getInt(KEY_CRYSTAL_GATE, 0),
      crystalBountyLevel = prefs.getInt(KEY_CRYSTAL_BOUNTY, 0),
      soundEnabled = prefs.getBoolean(KEY_SOUND, true),
      hapticsEnabled = prefs.getBoolean(KEY_HAPTICS, true)
    )
  }

  fun saveUpgrades(upgrades: PermanentUpgrades) {
    prefs.edit()
      .putInt(KEY_GOLD, upgrades.gold)
      .putInt(KEY_CRYSTALS, upgrades.crystals)
      .putInt(KEY_HIGH_SCORE, upgrades.highScore)
      .putInt(KEY_UNLOCKED_WAVE, upgrades.unlockedWave)
      .putInt(KEY_DAMAGE_LEVEL, upgrades.baseDamageLevel)
      .putInt(KEY_FIRE_RATE_LEVEL, upgrades.baseFireRateLevel)
      .putInt(KEY_FORTRESS_HP_LEVEL, upgrades.baseFortressHpLevel)
      .putInt(KEY_CRYSTAL_POWER, upgrades.crystalPowerLevel)
      .putInt(KEY_CRYSTAL_CRIT, upgrades.crystalCritLevel)
      .putInt(KEY_CRYSTAL_TURRET, upgrades.crystalTurretTechLevel)
      .putInt(KEY_CRYSTAL_GATE, upgrades.crystalGateMasteryLevel)
      .putInt(KEY_CRYSTAL_BOUNTY, upgrades.crystalBountyLevel)
      .putBoolean(KEY_SOUND, upgrades.soundEnabled)
      .putBoolean(KEY_HAPTICS, upgrades.hapticsEnabled)
      .apply()
  }

  fun loadStats(): PlayerStats {
    val claimedRaw = prefs.getStringSet(KEY_CLAIMED_ACHIEVEMENTS, emptySet()) ?: emptySet()
    return PlayerStats(
      totalRunsPlayed = prefs.getInt(KEY_RUNS_PLAYED, 0),
      totalZombiesKilled = prefs.getLong(KEY_ZOMBIES_KILLED, 0L),
      totalBossesKilled = prefs.getInt(KEY_BOSSES_KILLED, 0),
      totalElitesKilled = prefs.getInt(KEY_ELITES_KILLED, 0),
      totalLeftBarrelsBroken = prefs.getInt(KEY_LEFT_BARRELS, 0),
      totalRightBarrelsBroken = prefs.getInt(KEY_RIGHT_BARRELS, 0),
      bestEndlessThreatLevel = prefs.getInt(KEY_BEST_THREAT, 1),
      bestEndlessTimeSec = prefs.getInt(KEY_BEST_TIME_SEC, 0),
      bestScore = prefs.getInt(KEY_BEST_SCORE, 0),
      highestCampaignWave = prefs.getInt(KEY_HIGHEST_WAVE, 1),
      lifetimeGoldEarned = prefs.getLong(KEY_LIFETIME_GOLD, 150L),
      lifetimeCrystalsEarned = prefs.getLong(KEY_LIFETIME_CRYSTALS, 30L),
      claimedAchievementIds = claimedRaw.toSet()
    )
  }

  fun saveStats(stats: PlayerStats) {
    prefs.edit()
      .putInt(KEY_RUNS_PLAYED, stats.totalRunsPlayed)
      .putLong(KEY_ZOMBIES_KILLED, stats.totalZombiesKilled)
      .putInt(KEY_BOSSES_KILLED, stats.totalBossesKilled)
      .putInt(KEY_ELITES_KILLED, stats.totalElitesKilled)
      .putInt(KEY_LEFT_BARRELS, stats.totalLeftBarrelsBroken)
      .putInt(KEY_RIGHT_BARRELS, stats.totalRightBarrelsBroken)
      .putInt(KEY_BEST_THREAT, stats.bestEndlessThreatLevel)
      .putInt(KEY_BEST_TIME_SEC, stats.bestEndlessTimeSec)
      .putInt(KEY_BEST_SCORE, stats.bestScore)
      .putInt(KEY_HIGHEST_WAVE, stats.highestCampaignWave)
      .putLong(KEY_LIFETIME_GOLD, stats.lifetimeGoldEarned)
      .putLong(KEY_LIFETIME_CRYSTALS, stats.lifetimeCrystalsEarned)
      .putStringSet(KEY_CLAIMED_ACHIEVEMENTS, stats.claimedAchievementIds)
      .apply()
  }

  fun buildAchievementsList(
    stats: PlayerStats,
    perm: PermanentUpgrades
  ): List<AchievementDef> {
    val claimed = stats.claimedAchievementIds
    return listOf(
      AchievementDef(
        id = "kill_50",
        titleRu = "Первая Оборона",
        descriptionRu = "Уничтожить 50 зомби на мосту",
        rewardCrystals = 15,
        currentProgress = stats.totalZombiesKilled.toInt().coerceAtMost(50),
        targetProgress = 50,
        isClaimed = "kill_50" in claimed
      ),
      AchievementDef(
        id = "kill_500",
        titleRu = "Гроза Орды",
        descriptionRu = "Уничтожить 500 зомби за всё время",
        rewardCrystals = 35,
        currentProgress = stats.totalZombiesKilled.toInt().coerceAtMost(500),
        targetProgress = 500,
        isClaimed = "kill_500" in claimed
      ),
      AchievementDef(
        id = "kill_2500",
        titleRu = "Легендарный Зачистчик",
        descriptionRu = "Уничтожить 2 500 зомби за всё время",
        rewardCrystals = 90,
        currentProgress = stats.totalZombiesKilled.toInt().coerceAtMost(2500),
        targetProgress = 2500,
        isClaimed = "kill_2500" in claimed
      ),
      AchievementDef(
        id = "left_barrels_10",
        titleRu = "Боевой Ботаник",
        descriptionRu = "Разбить 10 бочек растений в левой полосе",
        rewardCrystals = 25,
        currentProgress = stats.totalLeftBarrelsBroken.coerceAtMost(10),
        targetProgress = 10,
        isClaimed = "left_barrels_10" in claimed
      ),
      AchievementDef(
        id = "right_barrels_25",
        titleRu = "Оружейный Мастер",
        descriptionRu = "Разбить 25 бочек усилений в правой полосе",
        rewardCrystals = 35,
        currentProgress = stats.totalRightBarrelsBroken.coerceAtMost(25),
        targetProgress = 25,
        isClaimed = "right_barrels_25" in claimed
      ),
      AchievementDef(
        id = "boss_1",
        titleRu = "Охотник на Гигантов",
        descriptionRu = "Сокрушить 1 Босса-Гаргантюа",
        rewardCrystals = 30,
        currentProgress = stats.totalBossesKilled.coerceAtMost(1),
        targetProgress = 1,
        isClaimed = "boss_1" in claimed
      ),
      AchievementDef(
        id = "boss_10",
        titleRu = "Покоритель Титанов",
        descriptionRu = "Победить 10 Боссов-Гаргантюа",
        rewardCrystals = 80,
        currentProgress = stats.totalBossesKilled.coerceAtMost(10),
        targetProgress = 10,
        isClaimed = "boss_10" in claimed
      ),
      AchievementDef(
        id = "elites_50",
        titleRu = "Охотник на Мутантов",
        descriptionRu = "Уничтожить 50 элитных врагов (Щитоносцы, Мутанты, Шаманы, Киборги)",
        rewardCrystals = 45,
        currentProgress = stats.totalElitesKilled.coerceAtMost(50),
        targetProgress = 50,
        isClaimed = "elites_50" in claimed
      ),
      AchievementDef(
        id = "endless_threat_5",
        titleRu = "Закалённый в Бесконечности",
        descriptionRu = "Достичь 5-го Уровня Угрозы в Бесконечном режиме",
        rewardCrystals = 40,
        currentProgress = stats.bestEndlessThreatLevel.coerceAtMost(5),
        targetProgress = 5,
        isClaimed = "endless_threat_5" in claimed
      ),
      AchievementDef(
        id = "endless_threat_10",
        titleRu = "Властелин Моста",
        descriptionRu = "Достичь 10-го Уровня Угрозы в Бесконечном режиме",
        rewardCrystals = 100,
        currentProgress = stats.bestEndlessThreatLevel.coerceAtMost(10),
        targetProgress = 10,
        isClaimed = "endless_threat_10" in claimed
      ),
      AchievementDef(
        id = "upgrades_10",
        titleRu = "Инженер Эволюции",
        descriptionRu = "Приобрести суммарно 10 уровней постоянных улучшений",
        rewardCrystals = 50,
        currentProgress = perm.totalUpgradeLevels.coerceAtMost(10),
        targetProgress = 10,
        isClaimed = "upgrades_10" in claimed
      )
    )
  }

  companion object {
    private const val KEY_GOLD = "gold"
    private const val KEY_CRYSTALS = "crystals"
    private const val KEY_HIGH_SCORE = "high_score"
    private const val KEY_UNLOCKED_WAVE = "unlocked_wave"
    private const val KEY_DAMAGE_LEVEL = "damage_level"
    private const val KEY_FIRE_RATE_LEVEL = "fire_rate_level"
    private const val KEY_FORTRESS_HP_LEVEL = "fortress_hp_level"
    private const val KEY_CRYSTAL_POWER = "crystal_power"
    private const val KEY_CRYSTAL_CRIT = "crystal_crit"
    private const val KEY_CRYSTAL_TURRET = "crystal_turret"
    private const val KEY_CRYSTAL_GATE = "crystal_gate"
    private const val KEY_CRYSTAL_BOUNTY = "crystal_bounty"
    private const val KEY_SOUND = "sound_enabled"
    private const val KEY_HAPTICS = "haptics_enabled"

    private const val KEY_RUNS_PLAYED = "runs_played"
    private const val KEY_ZOMBIES_KILLED = "zombies_killed"
    private const val KEY_BOSSES_KILLED = "bosses_killed"
    private const val KEY_ELITES_KILLED = "elites_killed"
    private const val KEY_LEFT_BARRELS = "left_barrels"
    private const val KEY_RIGHT_BARRELS = "right_barrels"
    private const val KEY_BEST_THREAT = "best_threat"
    private const val KEY_BEST_TIME_SEC = "best_time_sec"
    private const val KEY_BEST_SCORE = "best_score"
    private const val KEY_HIGHEST_WAVE = "highest_wave"
    private const val KEY_LIFETIME_GOLD = "lifetime_gold"
    private const val KEY_LIFETIME_CRYSTALS = "lifetime_crystals"
    private const val KEY_CLAIMED_ACHIEVEMENTS = "claimed_achievements"
  }
}
